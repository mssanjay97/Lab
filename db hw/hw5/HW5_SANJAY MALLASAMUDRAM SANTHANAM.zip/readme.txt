myPic.jpeg is a dog,baby corgi, which is misclassified as a cat i.e. 0
myPic2.jpeg is a cat, thin cat which is misclassified as a dog i.e. 1

what1.jpeg is a cat which is classified correctly as a cat i.e. 0
what2.jpeg is a dog which is classified correctly as a dog i.e. 1
